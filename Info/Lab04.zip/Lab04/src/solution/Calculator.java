package solution;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * Calculator class.
 * @author Victor C Thompson
 *
 */
public class Calculator
{
    private JFrame calcFrame;
    private JPanel buttonPanel;
    private JPanel resultPanel;
    private JPanel textFieldPanel;
    private JLabel resultLabel;
    private JButton addButton;
    private JButton subButton;
    private JButton multButton;
    private JButton divButton;
    private JTextField leftOperand;
    private JTextField rightOperand;
    
    /**
     * Main method; calls constructor.
     * @param args not used
     */
    public static void main(String[] args)
    {
        Calculator calc = new Calculator();
    }
    
    /**
     * creates new frame.
     */
    public Calculator()
    {
        calcFrame = new JFrame("Simple Calculator");
        initializeComponents();
        calcFrame.setSize(400, 150);
        calcFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        calcFrame.setVisible(true);
    }
    
    /**
     * initializes GUI components.
     */
    public void initializeComponents()
    {
        buttonPanel = new JPanel();
        resultPanel = new JPanel();
        textFieldPanel = new JPanel();
        
        resultLabel = new JLabel("Result = ");
        resultLabel.setName("resultLabel");
        
        addButton = new JButton("ADD");
        addButton.setName("addButton");
        subButton = new JButton("SUB");
        subButton.setName("subButton");
        multButton = new JButton("MULT");
        multButton.setName("multButton");
        divButton = new JButton("DIV");
        divButton.setName("divButton");
        
        addButton.addActionListener(new AddClass());
        subButton.addActionListener(new SubClass());
        multButton.addActionListener(new MultClass());
        divButton.addActionListener(new DivClass());
        
        buttonPanel.add(addButton);
        buttonPanel.add(subButton);
        buttonPanel.add(multButton);
        buttonPanel.add(divButton);    
        
        resultPanel.add(resultLabel);
        
        leftOperand = new JTextField(10);
        leftOperand.setName("leftOperand");
        rightOperand = new JTextField(10);
        rightOperand.setName("rightOperand");
        
        textFieldPanel.add(leftOperand);
        textFieldPanel.add(rightOperand);
        
        calcFrame.add(buttonPanel, BorderLayout.PAGE_END);
        calcFrame.add(resultPanel, BorderLayout.CENTER);
        calcFrame.add(textFieldPanel, BorderLayout.PAGE_START);
    }
    
    /**
     * getter for frame.
     * @return calcFrame 
     */
    public JFrame getFrame()
    {
        return calcFrame;
    }
    
    /**
     * Inner class connected to addButton
     * @author Victor C Thompson
     *
     */
    public class AddClass implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            try 
            {
            String left = leftOperand.getText();
            String right = rightOperand.getText();
            
            Double sum = Double.parseDouble(left) + 
                Double.parseDouble(right);
            
            resultLabel.setText("Result = " + sum.toString());
            }
            catch (NumberFormatException exc)
            {
                resultLabel.setText("Result = Error");
            }
        }
    }
    
    /**
     * Inner class connected to subButton
     * @author Victor C Thompson
     *
     */
    public class SubClass implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            try
            {
            String left = leftOperand.getText();
            String right = rightOperand.getText();
            
            Double diff = Double.parseDouble(left) - 
                Double.parseDouble(right);
            
            resultLabel.setText("Result = " + diff.toString());
            }
            catch (NumberFormatException exc)
            {
                resultLabel.setText("Result = Error");
            }
        }
    }
    
    /**
     * Inner class connected to multButton
     * @author Victor C Thompson
     *
     */
    public class MultClass implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            try
            {
            String left = leftOperand.getText();
            String right = rightOperand.getText();
            
            Double prod = Double.parseDouble(left) * 
                Double.parseDouble(right);
            
            resultLabel.setText("Result = " + prod.toString());
            }
            catch (NumberFormatException exc)
            {
                resultLabel.setText("Result = Error");
            }
        }
    }
    
    /**
     * Inner class connected to divButton
     * @author Victor C Thompson
     *
     */
    public class DivClass implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            try
            {
            String left = leftOperand.getText();
            String right = rightOperand.getText();
            
                if (Double.parseDouble(right) == 0)
                {
                    resultLabel.setText("Result = Error");
                }
                else
                {
                    Double quotient = Double.parseDouble(left) / 
                        Double.parseDouble(right);
            
                    resultLabel.setText("Result = " + quotient.toString());
                }   
            }
            catch (NumberFormatException exc)
            {
                resultLabel.setText("Result = Error");
            }        
        }
    }
}
